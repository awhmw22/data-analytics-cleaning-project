import pandas as pd

# Load Excel file
file_path = "Dataset for Data Analytics.xlsx"

df = pd.read_excel(file_path)

# -----------------------------
# VIEW DATASET
# -----------------------------
print("First 5 Rows:")
print(df.head())

print("\nDataset Information:")
print(df.info())

print("\nMissing Values:")
print(df.isnull().sum())

# -----------------------------
# HANDLE MISSING VALUES
# -----------------------------
df["CouponCode"] = df["CouponCode"].fillna("No Coupon")

# -----------------------------
# REMOVE DUPLICATES
# -----------------------------
before = len(df)

df = df.drop_duplicates()

after = len(df)

print("\nDuplicates Removed:", before - after)

# -----------------------------
# FIX DATE FORMAT
# -----------------------------
df["Date"] = pd.to_datetime(df["Date"], errors="coerce")

# Count invalid dates
invalid_dates = df["Date"].isnull().sum()

print("\nInvalid Dates:", invalid_dates)

# -----------------------------
# CHECK DUPLICATE ORDER IDs
# -----------------------------
duplicate_ids = df["OrderID"].duplicated().sum()

print("\nDuplicate Order IDs:", duplicate_ids)

# -----------------------------
# SAVE CLEANED DATASET
# -----------------------------
output_file = "Cleaned_Dataset.xlsx"

df.to_excel(output_file, index=False)

print("\nCleaned dataset saved successfully!")

# -----------------------------
# FINAL VERIFICATION
# -----------------------------
if duplicate_ids == 0 and invalid_dates == 0:
    print("\n✔ Project Completed Successfully")
    print("✔ Zero duplicate IDs")
    print("✔ Zero incorrectly formatted dates")
else:
    print("\n⚠ Some issues still exist")